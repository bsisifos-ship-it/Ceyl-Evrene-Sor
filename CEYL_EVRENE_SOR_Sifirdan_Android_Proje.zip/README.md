# CEYL EVRENE SOR

Sıfırdan hazırlanmış Android uygulama kaynak projesi.

Özellikler:
- 5 cevap: EVET, HAYIR, BELKİ, KESİNLİKLE, İMKÂNSIZ
- Reklam SDK'sı yok
- İnternet izni yok
- Hesap/üyelik yok
- Soru cihazdan çıkmaz
- Mistik, siyah-altın arayüz
- Ceyl markalı ana ekran
- Cevap animasyonu

Play Store hedefi: Android App Bundle (.aab)

Not: Bu çalışma kaynak proje seviyesindedir. Bu oturumun çalışma ortamında Android SDK/Gradle derleyicisi bulunmadığından imzalı APK/AAB burada derlenmemiştir.
