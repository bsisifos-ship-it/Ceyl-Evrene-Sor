package com.ceyl.evrenesor

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.random.Random

private val Black = Color(0xFF050509)
private val Gold = Color(0xFFE7C98A)
private val SoftGold = Color(0xFFBFA16A)
private val Muted = Color(0xFFB4ADB8)
private val Panel = Color(0xFF0C0B11)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CeylEvreneSorApp() }
    }
}

@Composable
fun CeylEvreneSorApp() {
    var question by remember { mutableStateOf("") }
    var answer by remember { mutableStateOf<String?>(null) }
    var isRevealing by remember { mutableStateOf(false) }
    val scale = remember { Animatable(0.75f) }

    val answers = remember { listOf("EVET", "HAYIR", "BELKİ", "KESİNLİKLE", "İMKÂNSIZ") }

    LaunchedEffect(isRevealing) {
        if (isRevealing) {
            answer = null
            scale.snapTo(0.7f)
            scale.animateTo(1.08f, tween(650, easing = FastOutSlowInEasing))
            delay(350)
            answer = answers[Random.nextInt(answers.size)]
            scale.animateTo(1f, tween(350))
            isRevealing = false
        }
    }

    MaterialTheme {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xFF030305), Color(0xFF0B090E), Color(0xFF030305))
                    )
                )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 22.dp, vertical = 18.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(Modifier.height(18.dp))

                // Logo: C = crescent, Y = deer head, L = plain L.
                Text("☾  C   ♢   L", color = Gold, fontSize = 31.sp, fontWeight = FontWeight.Bold)
                Text(
                    "CEYL EVRENE SOR",
                    color = Gold,
                    fontSize = 25.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 2.sp
                )
                Spacer(Modifier.height(7.dp))
                Text(
                    "Sorunu düşün. Cevabını evrenden al.",
                    color = Muted,
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center
                )

                Spacer(Modifier.height(24.dp))

                OutlinedTextField(
                    value = question,
                    onValueChange = { if (it.length <= 200) question = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(128.dp),
                    placeholder = {
                        Text("Sormak istediğin soruyu yaz...", color = Color(0xFF77717E))
                    },
                    textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Gold,
                        unfocusedBorderColor = Color(0xFF5A4A36),
                        cursorColor = Gold,
                        focusedContainerColor = Panel,
                        unfocusedContainerColor = Panel
                    ),
                    shape = RoundedCornerShape(18.dp)
                )

                Box(Modifier.fillMaxWidth()) {
                    Text(
                        "${question.length}/200",
                        color = SoftGold,
                        fontSize = 11.sp,
                        modifier = Modifier.align(Alignment.CenterEnd).padding(top = 5.dp)
                    )
                }

                Spacer(Modifier.height(20.dp))

                Button(
                    onClick = { if (question.trim().isNotEmpty()) isRevealing = true },
                    enabled = !isRevealing,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(58.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF19130C),
                        contentColor = Gold,
                        disabledContainerColor = Color(0xFF100E0D),
                        disabledContentColor = SoftGold
                    ),
                    shape = RoundedCornerShape(30.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Gold)
                ) {
                    Text("✦  EVRENE SOR  ✦", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                }

                Spacer(Modifier.height(26.dp))

                Box(
                    modifier = Modifier
                        .height(112.dp)
                        .fillMaxWidth(),
                    contentAlignment = Alignment.Center
                ) {
                    if (isRevealing) {
                        Text("✦", color = Gold, fontSize = 54.sp, modifier = Modifier.scale(scale.value))
                    } else if (answer != null) {
                        Box(
                            modifier = Modifier
                                .size(102.dp)
                                .scale(scale.value)
                                .background(Color(0xFF111017), CircleShape)
                                .border(1.dp, Gold, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                answer!!,
                                color = Gold,
                                fontSize = if (answer == "KESİNLİKLE" || answer == "İMKÂNSIZ") 13.sp else 17.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                        }
                    } else {
                        Text("☾", color = Color(0xFF5E526A), fontSize = 40.sp)
                    }
                }

                if (answer != null && !isRevealing) {
                    TextButton(onClick = {
                        question = ""
                        answer = null
                    }) {
                        Text("↻  YENİDEN SOR", color = Muted)
                    }
                }

                Spacer(Modifier.weight(1f))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Color(0xFF29242D), RoundedCornerShape(16.dp))
                        .padding(vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    listOf("☀\nEVET", "☾\nHAYIR", "✦\nBELKİ", "✧\nKESİNLİKLE", "△\nİMKÂNSIZ").forEach {
                        Text(
                            it,
                            color = Muted,
                            fontSize = 10.sp,
                            textAlign = TextAlign.Center,
                            lineHeight = 15.sp
                        )
                    }
                }

                Spacer(Modifier.height(16.dp))
                Text(
                    "Reklamsız • İnternetsiz • Ceyl",
                    color = Color(0xFF665E69),
                    fontSize = 10.sp
                )
                Spacer(Modifier.height(4.dp))
            }
        }
    }
}
